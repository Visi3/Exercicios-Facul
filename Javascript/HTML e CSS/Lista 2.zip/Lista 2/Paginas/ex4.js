function chato(){
    
}
function feliz(){
    
}
function triste(){
    
}